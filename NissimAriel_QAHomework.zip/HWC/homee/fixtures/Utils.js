const Utils = {

    User_Details: {
        url: 'https://homme.co.il/',
        name: "tester",
        password: "tester123!@#qwe"
    },
    
    Appartment_Detalis: {
        type: "דירת גן",
        status: "משופץ",
        city: "כרמיאל",
        street: "אטד",
        number: "26"  
    },

    Asset_Area: {
        floor: "0",
        floors: "3",
        rooms: "4.5",
        parkings: "1",
        elavator: "ללא",
        terraces: "2",
        area: "120",
        gardenArea: "50"

    },

    Asset_Features: {
        features: "משופצת",
        description: "beautiful apartment"
    },

    Asset_Payments: {
        price: "7000",
        payments: "10",
        houseCommette: "100",
        taxes: "200",
        month: "November",
    },

    Asset_Picture: {
        path: "/Users/nissimariel/Desktop/house.png"
    },

    Personal_Details: {
        name: "Nissim Ariel",
        phone: "0521234567"
    },

    Ad_Details: {
        fullAddress: "כרמיאל 26",
        adPrice: "₪7,000",
        stautus: " משופץ",
        area: " 120",
        terraces: " 2",
        payments: " 10",
        tax: "ארנונה (לחודשיים): ₪200",
        homeCommetee: "ועד בית (לחודש): ₪100",
        park: " 1",
        garden: " 50",

    }






}

module.exports = {Utils};